from app.config.mysqlconnection import connectToMySQL 
import re # the regex module 
# create a regular expression object that we'll use later    
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 
from flask import flash 
 
class User: 
    db_name = "ideas_brillantes" 
    def __init__(self,data): 
        self.id = data['id'] 
        self.name = data['name'] 
        self.alias = data['alias'] 
        self.email = data['email'] 
        self.password = data['password'] 
        self.created_at = data['created_at'] 
 
    @classmethod 
    def save(cls,data): 
        query = """INSERT INTO usuarios (name,alias,email,password,created_at)
        VALUES(%(name)s,%(alias)s,%(email)s,%(password)s, NOW())"""
        return connectToMySQL(cls.db_name).query_db(query,data) 
 
    @classmethod 
    def get_by_email(cls,data): 
        query = "SELECT * FROM usuarios WHERE email = %(email)s;" 
        results = connectToMySQL(cls.db_name).query_db(query,data) 
        if len(results) < 1: 
            return False 
        return cls(results[0]) 

    @classmethod 
    def get_by_id(cls,data): 
        query = "SELECT * FROM usuarios WHERE id = %(id)s;" 
        results = connectToMySQL(cls.db_name).query_db(query,data) 
        return cls(results[0]) 
 
    @staticmethod 
    def validate_register(user): 
        is_valid = True 
        query = "SELECT * FROM usuarios WHERE email = %(email)s;" 
        results = connectToMySQL(User.db_name).query_db(query,user) 
        if len(results) >= 1: 
            flash("Email ya registrado.","register") 
            is_valid=False 
        if len(user['name']) < 6: 
            flash("Nombre 6 caracteres minnimo","register") 
            is_valid= False 
        if len(user['alias']) < 3: 
            flash("Alias 3 caracteres minimo","register") 
            is_valid= False 
        if not EMAIL_REGEX.match(user['email']): 
            flash("Email no válido","register") 
            is_valid=False 
        if len(user['password']) < 8: 
            flash("Contraseña 8 caracteres minimo","register") 
            is_valid= False 
        if user['password'] != user['confirm']: 
            flash("Las contraseñas no coinciden","register")
            is_valid= False 
        return is_valid 
 
    @staticmethod 
    def validate_login(user): 
        is_valid = True 
        query = "SELECT * FROM usuarios WHERE email = %(email)s;" 
        results = connectToMySQL(User.db_name).query_db(query,user) 
        if not EMAIL_REGEX.match(user['email']): 
            flash("Email no registrado/válido","login") 
            is_valid=False 
        if len(user['password']) < 8: 
            flash("La contraseña debe tener 8 caracteres como minimo","login") 
            is_valid= False
        if len(user['email']) < 1:
            flash("¡Por favor, completa los campos!","login")
            is_valid= False
        return is_valid