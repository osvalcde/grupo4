from app.config.mysqlconnection import connectToMySQL 
from flask import flash
 
class Idea: 
    db_name = 'ideas_brillantes' 
    def __init__(self,db_data): 
        self.id = db_data['id'] 
        self.idea = db_data['idea'] 
        self.usuario = db_data['usuario'] 
        self.created_at = db_data['created_at'] 
        self.updated_at=  db_data['updated_at']
        self.name = db_data['name']
        self.alias = db_data['alias']
        self.email = db_data['email']
        self.likes = db_data['likes']
 
    @classmethod 
    def save(cls,data): 
        query = "INSERT INTO ideas (idea, usuario, created_at, updated_at) VALUES (%(idea)s, %(usuario)s, NOW() , NOW());" 
        return connectToMySQL(cls.db_name).query_db(query, data) 

    @classmethod 
    def get_all(cls): 
        query = "Select i.id, i.idea, i.likes, usuario, i.created_at, i.updated_at, u.name, u.alias, u.email FROM ideas i left join usuarios u on i.usuario = u.id ORDER BY likes desc;"
        results =  connectToMySQL("ideas_brillantes").query_db(query) 
        all_ideas = [] 
        for i in results: 
            all_ideas.append( cls(i)) 
        return all_ideas
    
    @classmethod
    def get_one(cls,data):
        query = "Select i.id, i.idea, i.likes, usuario, i.created_at, i.updated_at, u.name, u.alias, u.email FROM ideas i left join usuarios u on i.usuario = u.id WHERE i.id = %(id)s;"
        results = connectToMySQL(cls.db_name).query_db(query,data)
        return cls(results[0])
    
    @classmethod 
    def destroy(cls,data): 
        query = "DELETE FROM ideas WHERE id = %(id)s;" 
        return connectToMySQL(cls.db_name).query_db(query,data) 
    
    @classmethod 
    def like(cls,data): 
        query = "UPDATE ideas SET likes = likes + 1 WHERE id = %(id)s;" 
        return connectToMySQL(cls.db_name).query_db(query,data)
    
    @classmethod 
    def get_likes(cls,data): 
        query = "SELECT SUM(likes) AS TotalLikes FROM ideas i left join usuarios u on i.usuario = u.id WHERE usuario = u.id;" 
        return connectToMySQL(cls.db_name).query_db(query,data)
    @classmethod 
    def get_posts(cls,data): 
        query = "SELECT count(*) AS TotalPosts FROM ideas i left join usuarios u on i.usuario = u.id WHERE usuario = u.id;" 
        return connectToMySQL(cls.db_name).query_db(query,data)

    @staticmethod 
    def validate_ideas(idea): 
        is_valid = True 
        if len(idea['idea']) < 8: 
            is_valid = False 
            flash("Ingresa una idea con 8 caracteres como minimo","idea") 
        if idea['idea'] == "": 
            is_valid = False 
            flash("Ingresa una idea","idea") 
        return is_valid 
    
    