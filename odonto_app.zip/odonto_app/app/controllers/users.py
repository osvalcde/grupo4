from flask import render_template,redirect,session,request, flash 
from app import app 
from app.models.user import User
from app.models.idea import Idea
from flask_bcrypt import Bcrypt 
bcrypt = Bcrypt(app) 
 
@app.route('/') 
def index(): 
    return render_template('index.html') 
 
@app.route('/inicio') 
def inicio(): 
    return render_template('inicio.html') 
 
@app.route('/register',methods=['POST']) 
def register(): 
    if not User.validate_register(request.form): 
        return redirect('/') 
    data ={  
        "name": request.form['name'], 
        "alias": request.form['alias'], 
        "email": request.form['email'], 
        "password": bcrypt.generate_password_hash(request.form['password']) 
    } 
    id = User.save(data) 
    session['user_id'] = id 
 
    return redirect('/dashboard') 
 

@app.route('/login',methods=['POST', 'GET']) 
def login(): 
    if not User.validate_login(request.form): 
        return redirect('/inicio') 
    else: 
        data = { 
            'email':request.form.get('email') 
        } 
        user = User.get_by_email(data) 
        if not user: 
            flash("Email no válido","login") 
            return redirect('/inicio') 
        if not bcrypt.check_password_hash(user.password, request.form['password']): 
            flash("Contraseña incorrecta","login") 
            return redirect('/inicio') 
        session['user_id'] = user.id 
    return redirect('/dashboard') 
 
@app.route('/dashboard') 
def dashboard(): 
    if 'user_id' not in session: 
        return redirect('/logout') 
    data ={ 
        'id': session['user_id'] 
    }
    return render_template('dashboard.html',user=User.get_by_id(data), ideas=Idea.get_all())

@app.route('/logout') 
def logout(): 
    session.clear() 
    return redirect('/')