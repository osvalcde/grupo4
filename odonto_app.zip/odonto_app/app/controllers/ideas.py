from flask import render_template,redirect,session,request, flash
from app import app
from app.models.idea import Idea
from app.models.user import User

@app.route('/create/idea',methods=['POST'])
def create_idea():
    if 'user_id' not in session:
        return redirect('/logout')
    if not Idea.validate_ideas(request.form):
        return redirect('/dashboard')
    print("Solicitud de formulario:", request.form)
    data = {
        "idea": request.form["idea"],
        "usuario": session["user_id"],
    }
    Idea.save(data)
    return redirect("/dashboard")


@app.route('/destroy/idea/<int:id>')
def destroy_idea(id):
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        "id":id
    }
    Idea.destroy(data)
    return redirect('/dashboard')

@app.route('/like/idea/<int:id>')
def like_idea(id):
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        "id":id
    }
    Idea.like(data)
    return redirect('/dashboard')

@app.route('/idea/<int:id>')
def show_idea(id):
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        "id":id
    }
    user_data = {
        "id":session['user_id']
    }
    sum = Idea.get_likes(data)
    count = Idea.get_posts(data)
    return render_template("show_idea.html",idea=Idea.get_one(data),user=User.get_by_id(user_data), sum=sum,count=count)
