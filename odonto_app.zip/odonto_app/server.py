from app.controllers import users
from app.controllers import ideas
from app import app

if __name__ == '__main__':
    app.run(debug=True) 